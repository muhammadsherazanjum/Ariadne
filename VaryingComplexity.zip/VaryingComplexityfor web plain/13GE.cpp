#include<iostream>
using namespace std;
#include <stdio.h>

int main()
{

int a, b, c, d, e, f, g, h, i, j;

    printf("Enter the values of 10 numeric variables i.e. a, b, c, d, e, f, g, h, i and j: ");
    scanf("%d %d %d %d %d %d %d %d %d %d",&a, &b, &c, &d, &e, &f, &g, &h, &i, &j);



if (c < b || (a == d &&  i<= e))
	{//Start of 1st if statement
	cout<<"I am branch # 1."<<endl;
	if (b < d && (c == e || c == j))
		{//Start of 2nd if statement
		cout<<"I am branch # 3."<<endl;
		}//End of 2nd if statement
	else
		{
		cout<<"I am branch # 2."<<endl;
		}
	}//End of 1st if statement
else
	{
	cout<<"I am branch # 0."<<endl;
	}



	cout << "I am the end of the program."<<endl;

	return 0;
}

