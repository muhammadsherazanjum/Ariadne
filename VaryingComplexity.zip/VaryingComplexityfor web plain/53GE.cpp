#include<iostream>
using namespace std;
#include <stdio.h>

int main()
{

int a, b, c, d, e, f, g, h, i, j;

    printf("Enter the values of 10 numeric variables i.e. a, b, c, d, e, f, g, h, i and j: ");
    scanf("%d %d %d %d %d %d %d %d %d %d",&a, &b, &c, &d, &e, &f, &g, &h, &i, &j);



if (c < b || (a == d &&  i<= e))
	{//Start of 1st if statement
	cout<<"I am branch # 1."<<endl;
	if (b < d && (c == e || c == j))
		{//Start of 2nd if statement
		cout<<"I am branch # 3."<<endl;
		if (a <= c && h < j  && i>= g)
			{//Start of 3rd if statement
			cout<<"I am branch # 5."<<endl;
			if (e >= c || f == e || c ==h)
				{//Start of 4th if statement
				cout<<"I am branch # 7."<<endl;
				if (d >= e || (a <= j && b>= g))
					{//Start of 5th if statement
					cout<<"I am branch # 9."<<endl;
					if (e > b || i <= j || g <= f)
						{//Start of 6th if statement
						cout<<"I am branch # 11."<<endl;
						}//End of 6th if statement
					else
						{
						cout<<"I am branch # 10."<<endl;
						}
					}//End of 5th if statement
				else
					{
					cout<<"I am branch # 8."<<endl;
					}
				}//End of 4th if statement
			else
				{
				cout<<"I am branch # 6."<<endl;
				}
			}//End of 3rd if statement
		else
			{
			cout<<"I am branch # 4."<<endl;
			}
		}//End of 2nd if statement
	else
		{
		cout<<"I am branch # 2."<<endl;
		}
	}//End of 1st if statement
else
	{
	cout<<"I am branch # 0."<<endl;
	}



	cout << "I am the end of the program."<<endl;

	return 0;
}

