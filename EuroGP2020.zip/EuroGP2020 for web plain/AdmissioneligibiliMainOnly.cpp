#include<iostream>
using namespace std;
#include <stdio.h>

int main()
{
int p, c, m; //for Physics, Chemistry and Maths

    printf("Enter marks of Physics, Chemistry and Maths: ");
    scanf("%d %d %d",&p, &c, &m);

   if (m>=65 && m<=100)
         if(p>=55 && p<=100)
             if(c>=50 && c<=100)
	        if((m+p+c)>=180||(m+p)>=140)
	           printf("The  candidate is eligible for admission.\n");
	        else
	          printf("The candidate is not eligible1.\n");
             else
	    printf("The candidate is not eligible2.\n");
         else
	   printf("The candidate is not eligible3.\n");
    else
     printf("The candidate is not eligible4.\n");

	return 0;
}

