#include<iostream>
using namespace std;
#include <stdio.h>

int main()
{

int unitsPurchased;

    printf("Enter number of units purchased: ");
    scanf("%d",&unitsPurchased);

        /* calculate the Volume-based Discount */
        if (unitsPurchased >= 20000) {
                cout<< "Discount is 40%"<<endl;
        } else if (unitsPurchased >= 10000) {
                cout<< "Discount is 35%"<<endl;
        } else if (unitsPurchased >= 5000) {
                cout<< "Discount is 30%"<<endl;
        } else if (unitsPurchased >= 2000) {
                cout<< "Discount is 25%"<<endl;
        } else if (unitsPurchased >= 1000) {
                cout<< "Discount is 20%"<<endl;
        } else if (unitsPurchased >= 500) {
                cout<< "Discount is 15%"<<endl;
        } else {
                cout<< "Discount is 0%"<<endl;
        }

	return 0;
}

