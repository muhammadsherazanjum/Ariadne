#include<iostream>
using namespace std;
#include <stdio.h>

int main()
{

int a, b, c, d, e;

    printf("Enter the values of a, b, c, d and e: ");
    scanf("%d %d %d %d %d",&a, &b, &c, &d, &e);

if(b>e || a==c) // Branch # 0 and 3.
	{
	// do something...
	if(d==10) // Branch # 1 and 2.
		{
		// do something...
		}
	else
		{
		// do something...
		}
	}
else if(b==e || d==100) // Branch # 4 and 9.
	{
	// do something...
	if(a>e) // Branch # 5 and 8.
		{
		// do something...
		if(e==591) // Branch # 6 and 7.
			{
			// do something...
			}
		else
			{
			// do something...
			}
		}
	else
		{
		// do something...
		}
	}
else
	{
	// do something...
	if(c==1809) // Branch # 10 and 13.
		{
		// do something...
		if(a==0) // Branch # 11 and 12.
			{
			// do something...
			}
		else
			{
			// do something...
			}
		}
	else
		{
		// do something...
		}
	}

	cout << "I am the end of the program."<<endl;

	return 0;
}

