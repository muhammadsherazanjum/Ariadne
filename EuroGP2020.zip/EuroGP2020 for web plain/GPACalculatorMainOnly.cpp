#include<iostream>
using namespace std;
#include <stdio.h>

int main()
{
int marks;

    printf("Enter the marks: ");
    scanf("%d",&marks);

        /* calculate the GPA */
        if (marks >= 70) {
                cout<< "GPA is 4.0"<<endl;
        } else if (marks >= 65) {
                cout<< "GPA is 3.7"<<endl;
        } else if (marks >= 60) {
                cout<< "GPA is 3.3"<<endl;
        } else if (marks >= 55) {
                cout<< "GPA is 3.0"<<endl;
        } else if (marks >= 50) {
                cout<< "GPA is 2.7"<<endl;
        } else if (marks >= 45) {
                cout<< "GPA is 2.3"<<endl;
        } else if (marks >= 40) {
                cout<< "GPA is 2.0"<<endl;
        } else if (marks >= 35) {
                cout<< "GPA is 1.0"<<endl;
        } else {
                cout<< "GPA is 0.0"<<endl;
        }

	return 0;
}

