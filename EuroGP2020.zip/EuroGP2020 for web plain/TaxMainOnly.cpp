#include<iostream>
using namespace std;
#include <stdio.h>

int main()
{

int income, tax;

    printf("Enter your income: ");
    scanf("%d",&income);

        /* calculate the income tax */
        if (income > 800000) {
                tax = 92000 + ((income - 180000) * 30)/100;
        } else if (income > 500000) {
                tax = 32000 + ((income - 180000) * 20)/100;
        } else if (income > 180000) {
                tax = ((income - 180000) * 10)/100;
        } else {
                tax = 0;
        }

        /* print the result */
	cout<<"Income tax for income "<<income <<" is "<<tax<<endl;

	return 0;
}

