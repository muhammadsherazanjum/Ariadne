#include<iostream>
using namespace std;
#include <stdio.h>

int main()
{

int A1cLevel; //unit of HBA1c level is mmol/mol

    printf("Enter A1c level: ");
    scanf("%d",&A1cLevel);

        /* Check the HBA1c levels */
        if (A1cLevel >= 48) {
                cout<< "Your level is Diabetes"<<endl;
        } else if (A1cLevel >= 42) {
                cout<< "Your level is Pre-diabetes"<<endl;
        } else {
                cout<< "Your level is Normal"<<endl;
        }

	return 0;
}

