#include<iostream>
using namespace std;
#include <stdio.h>

int main()
{

int a, b, c;

    printf("Enter the values of a, b and c: ");
    scanf("%d %d %d",&a, &b, &c);


if(a>b) // Branch # 0 and 1.
	{
	// do something...
	 if(a==9073) // Branch # 2 and 3.
		{
		// do something...
		if(b<1280) // Branch # 4 and 5.
			{
			// do something...
			if(b==c) // Branch # 6 and 7.
				{
				// do something...
				}
			else
				{
				// do something...
				}
			}
		else
			{
			// do something...
			}
		}
	else
		{
		// do something...
		}
	}
else
	{
	// do something...
	}

	cout << "I am the end of the program."<<endl;

	return 0;
}

