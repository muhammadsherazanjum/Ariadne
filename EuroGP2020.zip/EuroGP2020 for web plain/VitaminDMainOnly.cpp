#include<iostream>
using namespace std;
#include <stdio.h>

int main()
{

int vitaminDLevel; //unit of vitaminD level is ng/ml

    printf("Enter Vitamin-D Level: ");
    scanf("%d",&vitaminDLevel);

        /* Check the VitaminD levels */
        if (vitaminDLevel < 30) {
                cout<< "Your level is Deficient"<<endl;
        } else if (vitaminDLevel < 40) {
                cout<< "Your level is Adequate"<<endl;
        } else if (vitaminDLevel < 60) {
                cout<< "Your level is Optimal"<<endl;
        } else if (vitaminDLevel < 100) {
                cout<< "Your level is Therapeutic"<<endl;
        } else {
                cout<< "Your level is Excess"<<endl;
        }

	return 0;
}

