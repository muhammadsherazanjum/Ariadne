#include<iostream>
using namespace std;
#include <stdio.h>

int main()
{

int birthTimeWeight; //unit of weight is ounces

    printf("Enter Birth Time Weight of the newborn babay: ");
    scanf("%d",&birthTimeWeight);

        /* Check the weights of newborn babies */
        if (birthTimeWeight < 53) {
                cout<< "Weigh of new born is very low"<<endl;
        } else if (birthTimeWeight < 88) {
                cout<< "Weigh of new born is low"<<endl;
        } else if (birthTimeWeight < 155) {
                cout<< "Weigh of new born is Normal"<<endl;
        } else {
                cout<< "Weigh of new born is Obese"<<endl;
        }

	return 0;
}

